/*
 * Copyright (c) 1997, 2026, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.crypto.provider;

import javax.crypto.ShortBufferException;
import java.util.Arrays;

/**
 * This class implements padding as specified in the PKCS#5 standard.
 *
 * @author Gigi Ankeny
 *
 *
 * @see Padding
 */
final class PKCS5Padding implements Padding {

    private final int blockSize;

    PKCS5Padding(int blockSize) {
        this.blockSize = blockSize;
    }

    /**
     * Adds the given number of padding bytes to the data input.
     * The value of the padding bytes is determined
     * by the specific padding mechanism that implements this
     * interface.
     *
     * @param in the input buffer with the data to pad
     * @param off the offset in <code>in</code> where the padding bytes
     * are appended
     * @param len the number of padding bytes to add
     *
     * @exception ShortBufferException if <code>in</code> is too small to hold
     * the padding bytes
     */
    public void padWithLen(byte[] in, int off, int len)
        throws ShortBufferException
    {
        if (in == null)
            return;

        int idx = Math.addExact(off, len);
        if (idx > in.length) {
            throw new ShortBufferException("Buffer too small to hold padding");
        }

        byte paddingOctet = (byte) (len & 0xff);
        Arrays.fill(in, off, idx, paddingOctet);
    }

    /**
     * Returns the index where the padding starts.
     *
     * <p>Given a buffer with padded data, this method returns the
     * index where the padding starts.
     *
     * @param in the buffer with the padded data
     * @param off the offset in <code>in</code> where the padded data starts
     * @param len the length of the padded data
     *
     * @return the index where the padding starts, or -1 if the input is
     * not properly padded
     */
    public int unpad(byte[] in, int off, int len) {
        if ((in == null) ||
            (len == 0)) { // this can happen if input is really a padded buffer
            return 0;
        }

        int last = Math.addExact(off, len);
        int padValue = in[last - 1] & 0x0ff;
        // check padValue >= 1; negative if fail
        int invalid = (padValue - 1);
        // check padValue <= blockSize; negative if fail
        invalid |= (blockSize - padValue);

        // check the last block for the padding bytes
        for (int i = last - blockSize; i < last ; i++) {
            // mask = 0 for the first (blockSize - padValue) bytes in the block
            // otherwise, use 0xffff to preserve the value
            int mask = (last - padValue - i - 1) >> 8 ;
            int valueCheck = ((in[i] & 0x0ff) ^ padValue) & mask;
            // again, assign negative value if fail
            invalid |= -valueCheck;
        }
        // convert 'invalid' to -1 when 'invalid' is not 0
        // right shifting by 8 should be sufficient since value range is small
        invalid >>= 8; // 0 or -1
        return (invalid | (last - padValue));
    }

    /**
     * Determines how long the padding will be for a given input length.
     *
     * @param len the length of the data to pad
     *
     * @return the length of the padding
     */
    public int padLength(int len) {
        return blockSize - (len % blockSize);
    }
}
