/*
 * Copyright (c) 1995, 2025, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package java.lang;

/**
 * Thrown when a thread executing a blocking method is {@linkplain Thread#interrupt()
 * interrupted}. {@link Thread#sleep(long) Thread.sleep}, {@link Object#wait()
 * Object.wait} and many other blocking methods throw this exception if interrupted.
 *
 * <p> Blocking methods that throw {@code InterruptedException} clear the thread's
 * interrupted status before throwing the exception. Code that catches {@code
 * InterruptedException} should rethrow the exception, or restore the current thread's
 * interrupted status, with {@link Thread#currentThread()
 * Thread.currentThread()}.{@link Thread#interrupt() interrupt()}, before continuing
 * normally or handling it by throwing another type of exception.
 *
 * @author  Frank Yellin
 * @see     Thread##thread-interruption Thread Interruption
 * @since   1.0
 */
public class InterruptedException extends Exception {
    @java.io.Serial
    private static final long serialVersionUID = 6700697376100628473L;

    /**
     * Constructs an {@code InterruptedException} with no detail  message.
     */
    public InterruptedException() {
        super();
    }

    /**
     * Constructs an {@code InterruptedException} with the
     * specified detail message.
     *
     * @param   s   the detail message.
     */
    public InterruptedException(String s) {
        super(s);
    }
}
